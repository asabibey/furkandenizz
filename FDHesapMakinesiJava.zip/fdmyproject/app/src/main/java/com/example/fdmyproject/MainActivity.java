package com.example.fdmyproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    Button buttonToplama;
    Button buttonCikarma;
    Button buttonCarpma;
    Button buttonBolme;
    Button buttonArtiEksi;
    Button buttonSifir;
    Button buttonNokta;
    Button buttonClear;
    Button buttonBir;
    Button buttonIki;
    Button buttonUc;
    Button buttonDort;
    Button buttonBes;
    Button buttonAlti;
    Button buttonYedi;
    Button buttonSekiz;
    Button buttonDokuz;
    Button buttonSonuc;

    Double ilkSayi;
    TextView hesapEkrani;
    Boolean virgul;
    String islem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonToplama=findViewById(R.id.buttonToplama);
        buttonCikarma=findViewById(R.id.buttonCikarma);
        buttonCarpma=findViewById(R.id.buttonCarpma);
        buttonBolme=findViewById(R.id.buttonBolme);
        buttonArtiEksi=findViewById(R.id.buttonArtiEksi);
        buttonSifir=findViewById(R.id.buttonSifir);
        buttonNokta=findViewById(R.id.buttonNokta);
        buttonClear=findViewById(R.id.buttonClear);
        buttonBir=findViewById(R.id.buttonBir);
        buttonIki=findViewById(R.id.buttonIki);
        buttonUc=findViewById(R.id.buttonUc);
        buttonDort=findViewById(R.id.buttonDort);
        buttonBes=findViewById(R.id.buttonBes);
        buttonAlti=findViewById(R.id.buttonAlti);
        buttonYedi=findViewById(R.id.buttonYedi);
        buttonSekiz=findViewById(R.id.buttonSekiz);
        buttonDokuz=findViewById(R.id.buttonDokuz);
        buttonSonuc=findViewById(R.id.buttonSonuc);
        hesapEkrani=findViewById(R.id.hesapEkrani);
        hesapEkrani.setText("0");
        ilkSayi=0.0;
        virgul=false;
        islem="0";

        buttonSonuc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sembolTik("=");
            }
        });
        buttonToplama.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sembolTik("+");
            }
        });
        buttonCikarma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sembolTik("-");
            }
        });
        buttonCarpma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sembolTik("*");
            }
        });
        buttonBolme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sembolTik("/");
            }
        });
        buttonClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sembolTik("clear");
            }
        });
        buttonNokta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sembolTik(".");
            }
        });
        buttonSifir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numaraTik(0);
            }
        });
        buttonBir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numaraTik(1);
            }
        });
        buttonIki.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numaraTik(2);
            }
        });
        buttonUc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numaraTik(3);
            }
        });
        buttonDort.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numaraTik(4);
            }
        });
        buttonBes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numaraTik(5);
            }
        });
        buttonAlti.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numaraTik(6);
            }
        });
        buttonYedi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numaraTik(7);
            }
        });
        buttonSekiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numaraTik(8);
            }
        });
        buttonDokuz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numaraTik(9);
            }
        });



    }

    private void sembolTik(String sembol)
    {
        switch (sembol)
        {
            default:
            {
                if(hesapEkrani.getText().toString()=="+" || hesapEkrani.getText().toString()=="*"
                        || hesapEkrani.getText().toString()=="/" || hesapEkrani.getText().toString()=="-")
                {
                    if(islem=="*"||islem=="/") ilkSayi= -1*ilkSayi;
                }
                else
                {
                    ilkSayi = Double.parseDouble(hesapEkrani.getText().toString());
                }
                hesapEkrani.setText(sembol);
                islem=sembol;

            }
            break;
            case "clear":
            {
                ilkSayi = 0.0;
                hesapEkrani.setText("0");
                islem= "0";
            }
            break;
            case "=":
            {
                if(hesapEkrani.getText().toString() == "+" || hesapEkrani.getText().toString() == "*"
                        || hesapEkrani.getText().toString() == "/" || hesapEkrani.getText().toString() == "-")
                {

                }
                else
                {
                    switch(islem)
                    {
                        default:
                        {
                            hesapEkrani.setText(ilkSayi.toString());
                        }
                        break;
                        case "+":
                        {
                            ilkSayi = ilkSayi + Double.parseDouble(hesapEkrani.getText().toString());
                            hesapEkrani.setText(ilkSayi.toString());
                        }
                        break;
                        case "-":
                        {
                            ilkSayi = ilkSayi - Double.parseDouble(hesapEkrani.getText().toString());
                            hesapEkrani.setText(ilkSayi.toString());
                        }
                        break;
                        case "/":
                        {
                            ilkSayi = ilkSayi / Double.parseDouble(hesapEkrani.getText().toString());
                            hesapEkrani.setText(ilkSayi.toString());
                        }
                        break;
                        case "*":
                        {
                            ilkSayi = ilkSayi * Double.parseDouble(hesapEkrani.getText().toString());
                            hesapEkrani.setText(ilkSayi.toString());
                        }
                        break;

                    }
                }
            }
            break;
            case ".":
            {

            }
            break;
        }
    }
    private void numaraTik(int sayi )
    {
        if (hesapEkrani.getText().toString()=="0"){
            hesapEkrani.setText("");
        }
        else if(
                hesapEkrani.getText().toString()=="+" ||
                        hesapEkrani.getText().toString()=="*" ||
                        hesapEkrani.getText().toString()=="/" ||
                        hesapEkrani.getText().toString()=="-" )
        {
            hesapEkrani.setText("");
        }
        hesapEkrani.setText(hesapEkrani.getText() + String.valueOf(sayi));
    }


}
//Furkan Deniz 2018280074








